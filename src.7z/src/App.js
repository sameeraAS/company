import React, { Component } from 'react';
import './App.css';
import { BrowserRouter as Router, Switch, Route, Link } from 'react-router-dom';
import cap from './img/cap.png';
import viewjobs from './viewjobs';
import jobDetails from './jobdetails';
import Overview from './Overview';
import Main from './main';
class App extends Component {
  constructor() {
    super();
    this.handleClick = this.handleClick.bind(this);
  }
   handleClick(e) {
     
    e.preventDefault();
  }
   render() {

 
    return (
         <Router >
            <div>
             <Switch>
                  <Route exact path='/' component={Main}/>                            
                  <Route exact path='/details' component={jobDetails} />
               </Switch>
            </div>
         </Router>
    );
  }
}

export default App;
