import React, { Component } from 'react';
import  hashHistory  from 'react-router';
import './App.css';
import cap from './img/cap.png';
import { BrowserRouter as Router, Switch, Route, Link } from 'react-router-dom';
class viewjobs extends Component{
    render(){
return (
    <div className="App">
        <div class="container">
          <div class="card-deck">
            <div class="col-lg-4 py-2">
              <div class="card h-100 text-black bg-light">
                <div class="card-body">
                  <p class="card-title"><img src={cap} width="50px" /></p><br />
                  <table ><tr><td><h6>Senior Consultant</h6></td></tr>
                    <tr><td><p class="cap">Capgemini</p></td></tr>
                    <tr><td><p class="loc">Hyderabad,Telangana,India</p></td></tr>
                  </table>
                </div>
              </div>
            </div>


            <div class="col-lg-4 py-2">
              <div class="card h-100 text-black bg-light">
                <div class="card-body">
                  <p class="card-title"><img src={cap} width="50px" /></p><br />
                  <table ><tr><td><h6>Senior Consultant</h6></td></tr>
                    <tr><td><p class="cap">Capgemini</p></td></tr>
                    <tr><td><p class="loc">Hyderabad,Telangana,India</p></td></tr>
                  </table>
                </div>
              </div>
            </div>


            <div class="col-lg-4 py-2">
              <div class="card h-100 text-black bg-light">
                <div class="card-body">
                  <p class="card-title"><img src={cap} width="50px" /></p><br />
                  <table ><tr><td><h6>Senior Consultant</h6></td></tr>
                    <tr><td><p class="cap">Capgemini</p></td></tr>
                    <tr><td><p class="loc">Hyderabad,Telangana,India</p></td></tr>
                  </table>
                </div>
              </div>
            </div>

            <div class="col-lg-4 py-2">
              <div class="card h-100 text-black bg-light">
                <div class="card-body">
                  <p class="card-title"><img src={cap} width="50px" /></p><br />
                  <table ><tr><td><h6><a href="#jobs">Senior Consultant</a></h6></td></tr>
                    <tr><td><p class="cap"><a href="#jobs">Capgemini</a></p></td></tr>
                    <tr><td><p class="loc"><a href="#jobs">Hyderabad,Telangana,India</a></p></td></tr>
                  </table>
                </div>
              </div>
            </div>

            <div class="col-lg-4 py-2">
              <div class="card h-100 text-black bg-light">
                <div class="card-body">
                  <p class="card-title"><img src={cap} width="50px" /></p><br />
                  <table ><tr><td><h6>Senior Consultant</h6></td></tr>
                    <tr><td><p class="cap">Capgemini</p></td></tr>
                    <tr><td><p class="loc">Hyderabad,Telangana,India</p></td></tr>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
)
    }
}
export default viewjobs;