import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import cap from './img/cap.png';
import cview from './img/cview.png';
import { BrowserRouter as Router, Switch, Route, Link } from 'react-router-dom';
import Overview from './Overview';
import viewjobs from './viewjobs';
class Main extends Component {
    state =
        { flag: true }
    toggleimg() {
        var { flag } = this.state;
        flag = !flag;
        this.setState({ flag });
    }
    render() {
        return (
            <Router>
                <div class="container">
                    <div class="card-deck1">
                        <div class="col-lg-12">
                            <div class="card border-light">
                                <div class="card-body" >
                                    <div class="table">
                                        <tr>
                                            <td><img src={cap} alt="no image" width="100px" /></td>
                                            <td>Capgemini<br />Information Technology and Services    Paris    500000 followers
                                            <br />
                                                <button class='btn btn-primary' onClick={this.toggleimg.bind(this)}> {this.state.flag ? "Follow" : "Unfollow"}</button>&nbsp;
                                      <button class='btn btn'><Link to={'/viewjobs'}>See Jobs</Link></button></td>
                                        </tr>
                                    </div></div>
                            </div></div>
                        <div class="card-deck" >
                            <div class="col-lg-6">
                                <div class="card bg-light">
                                    <div class="card-body text-center">
                                        <p class="card-text text-left"><Link to={'/overview'}>Overview</Link></p>
                                    </div>
                                </div>
                                <Switch>
                                    <Route exact path='/overview' component={Overview} />
                                </Switch>                            
                            </div>
                            <div class="col-lg-6">
                                <div class="card bg-light">
                                    <div class="card-body text-center">
                                        <p class="card-text text-left"><Link to={'/viewjobs'}>Jobs</Link></p>
                                        <p class="card-text text-left"><span class="glyphicon glyphicon-user"></span>
                                            abcd xyz<br />Analyst at Capgemini</p>
                                    </div>
                                </div>
                            </div>
                            <Switch>
                                <Route exact path='/viewjobs' component={viewjobs} />
                            </Switch>
                        </div>
                    </div>
                </div>
            </Router>
        );
    }
}

export default Main;
