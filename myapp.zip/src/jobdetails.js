import React, { Component } from 'react';

import { BrowserRouter as Router, Switch, Route, Link } from 'react-router-dom';

class jobDetails extends Component
{
    render(){
        return (
         <h1>Hi Sahithi</h1>
        )
    }
}
export default jobDetails;