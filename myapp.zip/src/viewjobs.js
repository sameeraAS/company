import React, { Component } from 'react';
import  hashHistory  from 'react-router';
import './App.css';
import cap from './img/cap.png';
import { BrowserRouter as Router, Switch, Route, Link } from 'react-router-dom';
import axios from  'axios';
import cors from 'cors';

class viewjobs extends Component{
  constructor(props) {
    super(props);
    this.state = {
      companyName: '',
      companyArea:'' ,
      companyFollowers:'',
      companyLocations:''
    };    
  }
  componentWillMount() {

    //get particular company details
    axios.post('/orgs/get/', { "companyId": "C006" }).then(response => {
        this.setState({ companyName: response.data[0].name })
        console.log(response.data[0].name);
      }).catch(function (error) {
        console.log(error);
      });
    
    //get location of company
    axios.post('/orgs/getLocations/', { "companyId": "C006" }).then(response => {
      console.log(response)
        this.setState({ companyLocations: response.data[0].profile.locations})
        console.log(response.data[0].profile.locations);
      }).catch(function (error) {
        console.log(error);
      });
    
    }
    render(){
      
return (
    <div className="App">
        <div class="container">
          <div class="card-deck">
            <div class="col-lg-4 py-2">
              <div class="card h-100 text-black bg-light">
                <div class="card-body">
                  <p class="card-title"><img src={cap} width="50px" /></p><br />
                  <table ><tr><td><h6>Senior Consultant</h6></td></tr>
                    <tr><td><p class="cap">{this.state.companyName}</p></td></tr>
                    <tr><td><p class="loc">{this.state.companyLocations}</p></td></tr>
                  </table>
                </div>
              </div>
            </div>


            <div class="col-lg-4 py-2">
              <div class="card h-100 text-black bg-light">
                <div class="card-body">
                  <p class="card-title"><img src={cap} width="50px" /></p><br />
                  <table ><tr><td><h6>Senior Consultant</h6></td></tr>
                    <tr><td><p class="cap">Capgemini</p></td></tr>
                    <tr><td><p class="loc">Hyderabad,Telangana,India</p></td></tr>
                  </table>
                </div>
              </div>
            </div>


            <div class="col-lg-4 py-2">
              <div class="card h-100 text-black bg-light">
                <div class="card-body">
                  <p class="card-title"><img src={cap} width="50px" /></p><br />
                  <table ><tr><td><h6>Senior Consultant</h6></td></tr>
                    <tr><td><p class="cap">Capgemini</p></td></tr>
                    <tr><td><p class="loc">Hyderabad,Telangana,India</p></td></tr>
                  </table>
                </div>
              </div>
            </div>

            <div class="col-lg-4 py-2">
              <div class="card h-100 text-black bg-light">
                <div class="card-body">
                  <p class="card-title"><img src={cap} width="50px" /></p><br />
                  <table ><tr><td><h6><a href="#jobs">Senior Consultant</a></h6></td></tr>
                    <tr><td><p class="cap"><a href="#jobs">Capgemini</a></p></td></tr>
                    <tr><td><p class="loc"><a href="#jobs">Hyderabad,Telangana,India</a></p></td></tr>
                  </table>
                </div>
              </div>
            </div>

            <div class="col-lg-4 py-2">
              <div class="card h-100 text-black bg-light">
                <div class="card-body">
                  <p class="card-title"><img src={cap} width="50px" /></p><br />
                  <table ><tr><td><h6>Senior Consultant</h6></td></tr>
                    <tr><td><p class="cap">Capgemini</p></td></tr>
                    <tr><td><p class="loc">Hyderabad,Telangana,India</p></td></tr>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
)
    }
}
export default viewjobs;