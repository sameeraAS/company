import React, { Component } from 'react';

import './App.css';
import cap from './img/cap.png';
import cview from './img/cview.png';
import { BrowserRouter as Router, Switch, Route, Link } from 'react-router-dom';
import Overview from './Overview';
import viewjobs from './viewjobs';
import axios from  'axios';
import cors from 'cors';

axios.defaults.baseURL="http://localhost:8080";  

class Main extends Component {

 constructor(props) {
        super(props);
        this.state = {
          companyName: '',
          companyArea:'' ,
          companyFollowers:''
        };    
      }
      componentWillMount() {
    
        //get particular company details
        axios.post('/orgs/get/', { "companyId": "C003" }).then(response => {
            this.setState({ companyName: response.data[0].name })
            console.log(response.data[0].name);
          }).catch(function (error) {
            console.log(error);
          });
        
        //get area of company
        axios.post('/orgs/getArea/', { "companyId": "C003" }).then(response => {
            this.setState({ companyArea: response.data[0].areaOfWork})
            console.log(response.data[0].areaOfWork);
          }).catch(function (error) {
            console.log(error);
          });
        //get followers of company 
        axios.post('/orgs/getFollowers/', { "companyId": "C003" }).then(response => {
            this.setState({ companyFollowers: response.data[0].profile.followers})
            console.log(response.data[0].profile.followers.length);
          }).catch(function (error) {
            console.log(error);
          });
        }
    state =
        { flag: true }
    toggletext() {
        var { flag } = this.state;
        flag = !flag;
        this.setState({ flag });
    }
    seejobs(){
        window.open('/viewjobs','_self');
    }
    render() {
        return (
            <div class="container">
                <div class="card-deck1">
                    <div class="col-lg-12">
                        <div class="card border-light">
                            <div class="card-body" >
                                <div class="table">
                                    <tr>
                                        <td class='cap'><h2>{this.state.companyName}</h2><br/>
                                        <ul><li>
                                        <p>{this.state.companyArea}</p></li><li>{this.state.companyFollowers.length}&nbsp;followers</li></ul>
                                        <br/>
                                         <button class='btn btn-primary' onClick={this.toggletext.bind(this)}> {this.state.flag ? "Unfollow" : "Follow"}</button>&nbsp;
                                        <button class='btn btn-primary' onClick={this.seejobs.bind(this)}>See Jobs</button></td>
                                    </tr>
                                    </div></div>
                            </div></div>
                        <div class="card-deck" >
                            <div class="col-lg-6">
                                <div class="card bg-light">
                                    <div class="card-body text-center">
                                        <p class="card-text text-left"><Link to={'/overview'}>Overview</Link></p>
                                    </div>
                                    <switch>
                                    <Route exact path='/overview' component={Overview} /></switch>
                                </div>
                             
                                                     
                            </div>
         
                            <div class="col-lg-6">
                                <div class="card bg-light">
                                    <div class="card-body text-center">
                                        <p class="card-text text-left"><Link to={'/viewjobs'}>Jobs</Link></p>
                                        <p class="card-text text-left"><span class="glyphicon glyphicon-user"></span>
                                            abcd xyz<br />Analyst at Capgemini</p>
                                    </div>
                                </div>
                            </div>
                            
                        </div>
                    </div>
                </div>
            
        );
    }
}

export default Main;
